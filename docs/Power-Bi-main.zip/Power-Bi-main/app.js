// UNIGRAM Analytics (demo) — login local + dados sintéticos + 25+ visões

const AUTH = { user: "admin", pass: "admin" };
const AUTH_KEY = "unigram_auth";

function $(sel) {
  return document.querySelector(sel);
}
function $all(sel) {
  return Array.from(document.querySelectorAll(sel));
}

function fmt(n) {
  return new Intl.NumberFormat("pt-BR").format(Math.round(n));
}
function fmt1(n) {
  return new Intl.NumberFormat("pt-BR", { maximumFractionDigits: 1 }).format(n);
}

function clamp(n, a, b) {
  return Math.max(a, Math.min(b, n));
}

// RNG determinístico (mulberry32)
function mulberry32(seed) {
  let t = seed >>> 0;
  return function () {
    t += 0x6d2b79f5;
    let r = Math.imul(t ^ (t >>> 15), 1 | t);
    r ^= r + Math.imul(r ^ (r >>> 7), 61 | r);
    return ((r ^ (r >>> 14)) >>> 0) / 4294967296;
  };
}

function pick(rng, arr) {
  return arr[Math.floor(rng() * arr.length)];
}

function daysAgo(d) {
  const now = new Date();
  return new Date(now.getTime() - d * 24 * 60 * 60 * 1000);
}

function isoDay(d) {
  return d.toISOString().slice(0, 10);
}

function parseNanosDate(value) {
  if (!value) return null;
  const s = String(value);
  const base = s.length > 19 ? s.slice(0, 19) : s;
  const d = new Date(base);
  return isNaN(d.getTime()) ? null : d;
}

// ====== Dados base (a partir do que você tinha) ======

const basePersons = [
  { can_publish: true, name: "Aline Freitas", is_active: true, language: "pt-BR", email: "email_freitas_example@email.com", username: "aline.freitas", phone: "+5511999000022", gender: "female" },
  { can_publish: true, username: "ana.oliveira", name: "Ana Oliveira", email: "email_oliveira_example@email.com", is_active: true, gender: "female", language: "pt-BR", phone: "+5511999000004" },
  { username: "andre.batista", name: "André Batista", language: "pt-BR", email: "email_batista_example@email.com", phone: "+5511999000025", gender: "male", can_publish: true, is_active: true },
  { name: "Beatriz Lima", gender: "female", phone: "+5511999000008", username: "beatriz.lima", can_publish: true, language: "pt-BR", is_active: true, email: "email_lima_example@email.com" },
  { username: "bruno.ribeiro", name: "Bruno Ribeiro", is_active: true, email: "email_ribeiro_example@email.com", language: "pt-BR", can_publish: true, gender: "male", phone: "+5511999000011" },
  { name: "Camila Barros", can_publish: true, email: "email_barros_example@email.com", phone: "+5511999000014", language: "pt-BR", username: "camila.barros", is_active: true, gender: "female" },
  { can_publish: true, name: "Carolina Rocha", language: "pt-BR", is_active: true, username: "carolina.rocha", email: "email_rocha_example@email.com", phone: "+5511999000010", gender: "female" },
  { gender: "male", phone: "+5511999000021", can_publish: true, language: "pt-BR", username: "diego.teixeira", email: "email_teixeira_example@email.com", is_active: true, name: "Diego Teixeira" },
  { gender: "male", username: "felipe.azevedo", phone: "+5511999000023", email: "email_azevedo_example@email.com", can_publish: true, name: "Felipe Azevedo", is_active: true, language: "pt-BR" },
  { username: "fernanda.moura", language: "pt-BR", can_publish: true, phone: "+5511999000028", is_active: true, gender: "female", email: "email_moura_example@email.com", name: "Fernanda Moura" },
  { language: "pt-BR", can_publish: true, email: "email_almeida_example@email.com", phone: "+5511999000007", name: "Gabriel Almeida", username: "gabriel.almeida", gender: "male", is_active: true },
  { is_active: true, email: "email_araujo_example@email.com", username: "gustavo.araujo", phone: "+5511999000017", can_publish: true, gender: "male", language: "pt-BR", name: "Gustavo Araújo" },
  { username: "henrique.mendes", phone: "+5511999000019", can_publish: true, email: "email_mendes_example@email.com", gender: "male", name: "Henrique Mendes", is_active: true, language: "pt-BR" },
  { email: "email_barbosa_example@email.com", can_publish: true, name: "Isabela Barbosa", language: "pt-BR", username: "isabela.barbosa", gender: "female", is_active: true, phone: "+5511999000018" },
  { email: "joao@email.com", is_active: null, name: "Joao Silva", phone: "+551199999999", language: "pt", can_publish: true, username: "joao", gender: "male" },
  { phone: "+5511999000001", username: "joao.silva", email: "email_silva_example@email.com", can_publish: true, name: "João Silva", language: "pt-BR", is_active: true, gender: "male" },
  { phone: "+5511999000006", gender: "female", email: "email_costa_example@email.com", language: "pt-BR", can_publish: true, name: "Júlia Costa", is_active: true, username: "julia.costa" },
  { language: "pt-BR", name: "Juliana Campos", phone: "+5511999000030", email: "email_campos_example@email.com", gender: "female", can_publish: true, username: "juliana.campos", is_active: true },
  { name: "Larissa Martins", username: "larissa.martins", gender: "female", language: "pt-BR", is_active: true, email: "email_martins_example@email.com", phone: "+5511999000012", can_publish: true },
  { can_publish: true, language: "pt-BR", gender: "male", username: "leonardo.farias", phone: "+5511999000027", email: "email_farias_example@email.com", name: "Leonardo Farias", is_active: true },
  { language: "pt", username: "lucas", name: "Lucas Silva", email: "LucasSilva@email.com", can_publish: true, is_active: null, phone: "+55117777777", gender: "male" },
  { is_active: true, username: "lucas.pereira", email: "email_pereira_example@email.com", phone: "+5511999000005", language: "pt-BR", gender: "male", can_publish: true, name: "Lucas Pereira" },
  { phone: "+551198888888", name: "Maria Souza", email: "maria@email.com", language: "pt", gender: "female", username: "maria", is_active: null, can_publish: true },
  { phone: "+5511999000002", can_publish: true, username: "maria.souza", email: "email_souza_example@email.com", gender: "female", is_active: true, language: "pt-BR", name: "Maria Souza" },
  { phone: "+5511999000016", can_publish: true, gender: "female", name: "Mariana Melo", language: "pt-BR", email: "email_melo_example@email.com", username: "mariana.melo", is_active: true },
  { gender: "female", email: "email_nunes_example@email.com", is_active: true, username: "patricia.nunes", phone: "+5511999000020", language: "pt-BR", name: "Patrícia Nunes", can_publish: true },
  { email: "email_santos_example@email.com", language: "pt-BR", username: "pedro.santos", phone: "+5511999000003", can_publish: true, is_active: true, name: "Pedro Santos", gender: "male" },
  { phone: "+5511999000009", language: "pt-BR", is_active: true, gender: "male", email: "email_ferreira_example@email.com", name: "Rafael Ferreira", can_publish: true, username: "rafael.ferreira" },
  { email: "email_moraes_example@email.com", can_publish: true, gender: "female", phone: "+5511999000024", username: "renata.moraes", name: "Renata Moraes", language: "pt-BR", is_active: true },
  { is_active: true, can_publish: true, gender: "male", language: "pt-BR", email: "email_borges_example@email.com", phone: "+5511999000029", name: "Ricardo Borges", username: "ricardo.borges" },
  { gender: "female", email: "email_cavalcante_example@email.com", username: "taina.cavalcante", name: "Tainá Cavalcante", phone: "+5511999000026", is_active: true, can_publish: true, language: "pt-BR" },
  { name: "Thiago Cardoso", gender: "male", can_publish: true, email: "email_cardoso_example@email.com", language: "pt-BR", phone: "+5511999000015", is_active: true, username: "thiago.cardoso" },
  { language: "pt-BR", name: "Vinícius Gomes", username: "vinicius.gomes", email: "email_gomes_example@email.com", is_active: true, gender: "male", can_publish: true, phone: "+5511999000013" }
];

const baseLocations = [
  { "place-id": "BR", name: "Brasil" },
  { "place-id": "BR-SP", name: "São Paulo" },
  { "place-id": "BR-RJ", name: "Rio de Janeiro" },
  { "place-id": "BR-MG", name: "Minas Gerais" },
  { "place-id": "BR-PR", name: "Paraná" },
  { "place-id": "BR-RS", name: "Rio Grande do Sul" },
  { "place-id": "BR-SC", name: "Santa Catarina" },
  { "place-id": "BR-BA", name: "Bahia" },
  { "place-id": "BR-PE", name: "Pernambuco" },
  { "place-id": "BR-CE", name: "Ceará" },
  { "place-id": "BR-DF", name: "Distrito Federal" },
  { "place-id": "BR-SP-SAO-PAULO", name: "São Paulo" },
  { "place-id": "BR-SP-CAMPINAS", name: "Campinas" },
  { "place-id": "BR-SP-SANTOS", name: "Santos" },
  { "place-id": "BR-RJ-RIO-DE-JANEIRO", name: "Rio de Janeiro" },
  { "place-id": "BR-PR-CURITIBA", name: "Curitiba" },
  { "place-id": "BR-RS-PORTO-ALEGRE", name: "Porto Alegre" },
  { "place-id": "BR-DF-BRASILIA", name: "Brasília" }
];

// ====== Dataset sintético (LinkedIn acadêmico + social) ======

function buildDataset() {
  const rng = mulberry32(20260317);

  const courses = [
    "Análise e Desenvolvimento de Sistemas",
    "Engenharia de Software",
    "Ciência de Dados",
    "Redes de Computadores",
    "Engenharia Civil",
    "Administração",
    "Direito",
    "Psicologia",
    "Arquitetura e Urbanismo",
    "Enfermagem",
    "Farmácia",
    "Nutrição",
    "Ciências Contábeis",
  ];

  const cities = [
    "São Paulo",
    "Campinas",
    "Santos",
    "Rio de Janeiro",
    "Belo Horizonte",
    "Curitiba",
    "Porto Alegre",
    "Brasília",
    "Salvador",
    "Recife",
    "Fortaleza",
  ];

  const areas = [
    "Estágio",
    "Júnior",
    "Pleno",
    "Sênior",
    "Pesquisa",
    "Monitoria",
  ];

  const jobAreas = [
    "Tecnologia",
    "Dados",
    "Infra/Redes",
    "Saúde",
    "Admin/Finanças",
    "Jurídico",
    "Design/Arquitetura",
  ];

  const tagsPool = [
    "bd",
    "sql",
    "python",
    "redes",
    "vlan",
    "mfa",
    "kanban",
    "testes",
    "ia",
    "normalizacao",
    "direito",
    "financas",
    "saude",
    "estagio",
    "portfolio",
  ];

  const users = basePersons.map((p, i) => {
    const course = pick(rng, courses);
    const city = pick(rng, cities);
    return {
      id: `U${String(i + 1).padStart(3, "0")}`,
      ...p,
      course,
      city,
      headline: `${pick(rng, ["Estudante", "Monitor(a)", "Pesquisador(a)", "Estagiário(a)"])} • ${course}`,
    };
  });

  // Posts: reaproveita estilo + cria mais volume fictício no período
  const basePosts = [
    "Dica rápida de estudo: 25 minutos foco + 5 pausa. Funciona demais.",
    "Alguém tem indicação de material bom com exercícios?",
    "Comecei um projeto no GitHub pra treinar. Quem quiser participar, chama.",
    "Checklist que uso antes de entregar trabalho acadêmico.",
    "Resumo da aula de hoje + links úteis.",
    "Vaga de estágio aberta no meu time, mando detalhes no chat.",
    "Como eu organizo meu semestre com Kanban.",
    "Diferença prática entre índice e particionamento: exemplos rápidos.",
  ];

  const posts = [];
  const daysBack = 120;
  for (let d = 0; d < daysBack; d++) {
    const date = daysAgo(d);
    const volume = 2 + Math.floor(rng() * 6);
    for (let j = 0; j < volume; j++) {
      const author = pick(rng, users);
      const text = rng() < 0.08 ? null : pick(rng, basePosts);
      const tags = Array.from({ length: 1 + Math.floor(rng() * 3) }, () => pick(rng, tagsPool));
      const created = new Date(date.getTime() + Math.floor(rng() * 24) * 3600_000 + Math.floor(rng() * 60) * 60_000);
      const likes = 10 + Math.floor(rng() * 180);
      const shares = 0 + Math.floor(rng() * 45);
      const visibility = rng() < 0.92 ? "public" : "private";
      posts.push({
        id: `P${String(posts.length + 1).padStart(5, "0")}`,
        authorId: author.id,
        course: author.course,
        city: author.city,
        created,
        visibility,
        text,
        tags,
        likes,
        shares,
      });
    }
  }

  // Comentários (fictícios coerentes)
  const commentTemplates = [
    "Boa! Vou testar isso essa semana.",
    "Valeu por compartilhar, ajudou aqui.",
    "Você tem um exemplo prático disso?",
    "Concordo demais. Essa abordagem é a que mais funciona.",
    "Se quiser, te mando um material que tenho salvo.",
    "Top! Dá pra aplicar isso no projeto do semestre.",
  ];

  const comments = [];
  for (const post of posts) {
    const cCount = Math.floor(rng() * 8);
    for (let i = 0; i < cCount; i++) {
      const author = pick(rng, users);
      const created = new Date(post.created.getTime() + (10 + Math.floor(rng() * 60 * 24)) * 60_000);
      comments.push({
        id: `C${String(comments.length + 1).padStart(6, "0")}`,
        postId: post.id,
        authorId: author.id,
        created,
        text: pick(rng, commentTemplates),
      });
    }
  }

  // Vagas
  const companies = ["UNIGRAM", "TecNova", "DataPulse", "CampusLabs", "MedLink", "JusTech", "BuildStudio"];
  const jobs = [];
  for (let i = 0; i < 48; i++) {
    const area = pick(rng, jobAreas);
    const level = pick(rng, areas);
    const city = pick(rng, cities);
    const created = daysAgo(10 + Math.floor(rng() * 100));
    const views = 120 + Math.floor(rng() * 2200);
    const applies = Math.floor(views * (0.02 + rng() * 0.08));
    const interviews = Math.floor(applies * (0.25 + rng() * 0.35));
    const hires = Math.floor(interviews * (0.12 + rng() * 0.22));
    jobs.push({
      id: `J${String(i + 1).padStart(4, "0")}`,
      title: `${level} • ${area}`,
      company: pick(rng, companies),
      area,
      level,
      city,
      created,
      status: rng() < 0.82 ? "open" : "closed",
      views,
      applies,
      interviews,
      hires,
    });
  }

  // Aplicações (eventos por dia)
  const applications = [];
  for (const job of jobs) {
    const n = job.applies;
    for (let i = 0; i < n; i++) {
      const user = pick(rng, users);
      const created = new Date(job.created.getTime() + Math.floor(rng() * 60) * 24 * 3600_000);
      applications.push({
        id: `A${String(applications.length + 1).padStart(7, "0")}`,
        jobId: job.id,
        userId: user.id,
        city: user.city,
        course: user.course,
        created,
        stage: rng() < 0.65 ? "applied" : rng() < 0.90 ? "interview" : "hired",
      });
    }
  }

  // Gamificação por curso (pontos falsos, coerentes com atividade)
  const scoreByUser = new Map();
  users.forEach((u) => scoreByUser.set(u.id, 0));
  posts.forEach((p) => scoreByUser.set(p.authorId, scoreByUser.get(p.authorId) + (p.likes * 0.6 + p.shares * 1.6 + 8)));
  comments.forEach((c) => scoreByUser.set(c.authorId, scoreByUser.get(c.authorId) + 4));
  applications.forEach((a) => scoreByUser.set(a.userId, scoreByUser.get(a.userId) + (a.stage === "hired" ? 35 : a.stage === "interview" ? 12 : 6)));

  const gamification = users.map((u) => {
    const pts = Math.round(scoreByUser.get(u.id));
    const level = Math.max(1, Math.floor(Math.sqrt(pts) / 6));
    return { userId: u.id, course: u.course, points: pts, level };
  });

  return { users, courses, cities, posts, comments, jobs, applications, gamification };
}

// ====== Charts (SVG simples) ======

function clear(el) {
  if (el) el.innerHTML = "";
}

function svgEl(tag, attrs = {}) {
  const el = document.createElementNS("http://www.w3.org/2000/svg", tag);
  Object.entries(attrs).forEach(([k, v]) => el.setAttribute(k, String(v)));
  return el;
}

// Tooltip único (para todas as visões)
let TOOLTIP;
let CHART_SEQ = 0;
function ensureTooltip() {
  if (TOOLTIP) return TOOLTIP;
  TOOLTIP = document.createElement("div");
  TOOLTIP.className = "tooltip";
  TOOLTIP.innerHTML = `<div class="t" id="ttTitle"></div><div class="v" id="ttValue"></div><div class="s" id="ttSub"></div>`;
  document.body.appendChild(TOOLTIP);
  return TOOLTIP;
}
function showTip(x, y, title, value, sub = "") {
  const tip = ensureTooltip();
  tip.querySelector("#ttTitle").textContent = title;
  tip.querySelector("#ttValue").textContent = value;
  const subEl = tip.querySelector("#ttSub");
  subEl.textContent = sub;
  subEl.style.display = sub ? "block" : "none";
  const pad = 14;
  const w = 260;
  const left = clamp(x + 14, pad, window.innerWidth - w - pad);
  const top = clamp(y + 14, pad, window.innerHeight - 140 - pad);
  tip.style.left = `${left}px`;
  tip.style.top = `${top}px`;
  tip.classList.add("show");
}
function hideTip() {
  if (TOOLTIP) TOOLTIP.classList.remove("show");
}

function renderBars(container, items, { height = 140 } = {}) {
  clear(container);
  const entries = items.filter((x) => x.value > 0);
  if (!entries.length) {
    container.textContent = "Sem dados no filtro.";
    return;
  }
  const w = container.clientWidth || 520;
  const max = Math.max(...entries.map((e) => e.value));
  const svg = svgEl("svg", { viewBox: `0 0 ${w} ${height}`, preserveAspectRatio: "none" });
  const defs = svgEl("defs");
  const gid = `g${++CHART_SEQ}`;
  const grad = svgEl("linearGradient", { id: gid, x1: "0", y1: "0", x2: "0", y2: "1" });
  grad.appendChild(svgEl("stop", { offset: "0%", "stop-color": "#e9e4ff" }));
  grad.appendChild(svgEl("stop", { offset: "60%", "stop-color": "#6f4ff8" }));
  grad.appendChild(svgEl("stop", { offset: "100%", "stop-color": "#3ad6ff" }));
  defs.appendChild(grad);
  svg.appendChild(defs);

  const gap = 6;
  const barW = (w - gap * (entries.length - 1)) / entries.length;
  entries.forEach((e, i) => {
    const h = (e.value / max) * (height - 22);
    const x = i * (barW + gap);
    const y = height - 18 - h;
    const r = 10;
    const rect = svgEl("rect", { x, y, width: barW, height: h, rx: r, fill: `url(#${gid})`, opacity: "0.92" });
    rect.style.cursor = "default";
    rect.addEventListener("mousemove", (ev) => {
      showTip(ev.clientX, ev.clientY, "Valor", `${e.label}: ${fmt(e.value)}`, `Máx. na série: ${fmt(max)}`);
    });
    rect.addEventListener("mouseleave", hideTip);
    svg.appendChild(rect);
    const t = svgEl("text", { x: x + barW / 2, y: height - 6, "text-anchor": "middle", "font-size": "10", fill: "rgba(219,228,255,.80)" });
    t.textContent = e.label;
    svg.appendChild(t);
  });
  container.appendChild(svg);
}

function renderLine(container, points, { height = 140, stroke = "#3ad6ff" } = {}) {
  clear(container);
  if (!points.length) {
    container.textContent = "Sem dados no filtro.";
    return;
  }
  const w = container.clientWidth || 520;
  const svg = svgEl("svg", { viewBox: `0 0 ${w} ${height}`, preserveAspectRatio: "none" });
  const max = Math.max(...points.map((p) => p.value), 1);
  const min = Math.min(...points.map((p) => p.value), 0);
  const range = Math.max(1, max - min);
  const padTop = 10;
  const padBottom = 22;
  const innerH = height - padTop - padBottom;

  const toX = (i) => (points.length === 1 ? w / 2 : (i / (points.length - 1)) * w);
  const toY = (v) => padTop + (1 - (v - min) / range) * innerH;

  let d = "";
  points.forEach((p, i) => {
    d += `${i === 0 ? "M" : "L"} ${toX(i)} ${toY(p.value)} `;
  });

  const area = svgEl("path", {
    d: `${d} L ${toX(points.length - 1)} ${padTop + innerH} L ${toX(0)} ${padTop + innerH} Z`,
    fill: "rgba(58,214,255,.10)",
    stroke: "none",
  });
  svg.appendChild(area);
  svg.appendChild(svgEl("path", { d, fill: "none", stroke, "stroke-width": "2.2" }));

  // pontos (hover)
  points.forEach((p, i) => {
    const cx = toX(i);
    const cy = toY(p.value);
    const dot = svgEl("circle", { cx, cy, r: 3.6, fill: stroke, opacity: "0.95" });
    dot.style.cursor = "default";
    dot.addEventListener("mousemove", (ev) => {
      showTip(ev.clientX, ev.clientY, "Série", `${p.label}: ${fmt(p.value)}`);
    });
    dot.addEventListener("mouseleave", hideTip);
    svg.appendChild(dot);
  });

  const last = points[points.length - 1];
  const label = svgEl("text", { x: w - 6, y: 14, "text-anchor": "end", "font-size": "11", fill: "rgba(243,246,255,.92)" });
  label.textContent = `${fmt(last.value)}`;
  svg.appendChild(label);

  // eixo X simplificado
  const a = points[0]?.label ?? "";
  const b = points[points.length - 1]?.label ?? "";
  const xa = svgEl("text", { x: 0, y: height - 6, "text-anchor": "start", "font-size": "10", fill: "rgba(219,228,255,.75)" });
  xa.textContent = a;
  const xb = svgEl("text", { x: w, y: height - 6, "text-anchor": "end", "font-size": "10", fill: "rgba(219,228,255,.75)" });
  xb.textContent = b;
  svg.appendChild(xa);
  svg.appendChild(xb);

  container.appendChild(svg);
}

function renderDonut(container, segments) {
  clear(container);
  const total = segments.reduce((s, x) => s + x.value, 0);
  if (!total) {
    container.textContent = "Sem dados no filtro.";
    return;
  }
  const size = 140;
  const r = 48;
  const cx = 70;
  const cy = 64;
  const svg = svgEl("svg", { viewBox: `0 0 ${size} ${size}` });

  let start = -Math.PI / 2;
  const colors = ["#6f4ff8", "#3ad6ff", "#45e39a", "#ffb24a", "#ff4f74", "#b79cff"];
  segments.forEach((seg, i) => {
    const angle = (seg.value / total) * Math.PI * 2;
    const end = start + angle;
    const x1 = cx + r * Math.cos(start);
    const y1 = cy + r * Math.sin(start);
    const x2 = cx + r * Math.cos(end);
    const y2 = cy + r * Math.sin(end);
    const large = angle > Math.PI ? 1 : 0;
    const path = `M ${x1} ${y1} A ${r} ${r} 0 ${large} 1 ${x2} ${y2}`;
    const arc = svgEl("path", { d: path, stroke: colors[i % colors.length], "stroke-width": "12", fill: "none", "stroke-linecap": "round" });
    arc.style.cursor = "default";
    arc.addEventListener("mousemove", (ev) => {
      showTip(ev.clientX, ev.clientY, "Composição", `${seg.label}: ${fmt(seg.value)}`, `${fmt1((seg.value / total) * 100)}% do total`);
    });
    arc.addEventListener("mouseleave", hideTip);
    svg.appendChild(arc);
    start = end;
  });

  const center = svgEl("text", { x: cx, y: cy + 5, "text-anchor": "middle", "font-size": "16", fill: "rgba(243,246,255,.92)", "font-weight": "800" });
  center.textContent = fmt(total);
  svg.appendChild(center);

  // legenda compacta
  const legend = document.createElement("div");
  legend.style.marginTop = "8px";
  legend.style.display = "grid";
  legend.style.gap = "6px";
  segments.slice(0, 4).forEach((s, i) => {
    const row = document.createElement("div");
    row.style.display = "flex";
    row.style.justifyContent = "space-between";
    row.style.gap = "10px";
    row.style.fontSize = "12px";
    row.style.color = "rgba(219,228,255,.80)";
    row.innerHTML = `<span style="display:flex;gap:8px;align-items:center;"><span style="width:10px;height:10px;border-radius:99px;background:${colors[i % colors.length]};display:inline-block;"></span>${s.label}</span><span>${fmt(s.value)}</span>`;
    legend.appendChild(row);
  });

  container.appendChild(svg);
  container.appendChild(legend);
}

function renderBrazilMap(container, points) {
  clear(container);
  if (!points.length) {
    container.textContent = "Sem dados no filtro.";
    return;
  }

  // bounds aproximados do Brasil
  const bounds = { minLon: -74, maxLon: -34, minLat: -34, maxLat: 6 };
  const w = container.clientWidth || 820;
  const h = 320;
  const svg = svgEl("svg", { viewBox: `0 0 ${w} ${h}`, preserveAspectRatio: "none" });

  // fundo + grade sutil
  svg.appendChild(svgEl("rect", { x: 0, y: 0, width: w, height: h, fill: "rgba(255,255,255,.02)" }));
  for (let i = 1; i <= 5; i++) {
    const x = (w * i) / 6;
    svg.appendChild(svgEl("line", { x1: x, y1: 0, x2: x, y2: h, stroke: "rgba(255,255,255,.05)", "stroke-width": 1 }));
  }
  for (let i = 1; i <= 3; i++) {
    const y = (h * i) / 4;
    svg.appendChild(svgEl("line", { x1: 0, y1: y, x2: w, y2: y, stroke: "rgba(255,255,255,.05)", "stroke-width": 1 }));
  }

  const projX = (lon) => ((lon - bounds.minLon) / (bounds.maxLon - bounds.minLon)) * w;
  const projY = (lat) => (1 - (lat - bounds.minLat) / (bounds.maxLat - bounds.minLat)) * h;

  const max = Math.max(...points.map((p) => p.value), 1);

  points.forEach((p) => {
    const cx = projX(p.lon);
    const cy = projY(p.lat);
    const r = 6 + (p.value / max) * 18;
    const dot = svgEl("circle", { cx, cy, r, fill: "rgba(58,214,255,.25)", stroke: "rgba(58,214,255,.85)", "stroke-width": 2 });
    dot.addEventListener("mousemove", (ev) => {
      showTip(ev.clientX, ev.clientY, "Mapa", `${p.label}: ${fmt(p.value)}`, "Posts no período");
    });
    dot.addEventListener("mouseleave", hideTip);
    svg.appendChild(dot);

    const t = svgEl("text", { x: cx, y: cy - r - 4, "text-anchor": "middle", "font-size": "11", fill: "rgba(243,246,255,.85)" });
    t.textContent = p.label;
    svg.appendChild(t);
  });

  // legenda
  const legend = svgEl("text", { x: 10, y: 18, "text-anchor": "start", "font-size": "12", fill: "rgba(219,228,255,.75)" });
  legend.textContent = "Bolhas = volume de posts por cidade (demo)";
  svg.appendChild(legend);

  container.appendChild(svg);
}

function renderHeatmap(container, matrix, rowLabels, colLabels) {
  clear(container);
  if (!matrix.length || !matrix[0]?.length) {
    container.textContent = "Sem dados no filtro.";
    return;
  }
  const w = container.clientWidth || 520;
  const h = 140;
  const rows = matrix.length;
  const cols = matrix[0].length;
  const padL = 28;
  const padB = 18;
  const innerW = w - padL;
  const innerH = h - padB;
  const cellW = innerW / cols;
  const cellH = innerH / rows;
  const max = Math.max(...matrix.flat(), 1);
  const svg = svgEl("svg", { viewBox: `0 0 ${w} ${h}`, preserveAspectRatio: "none" });
  svg.appendChild(svgEl("rect", { x: 0, y: 0, width: w, height: h, fill: "rgba(255,255,255,.02)" }));

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const v = matrix[r][c];
      const a = 0.10 + 0.75 * (v / max);
      const x = padL + c * cellW;
      const y = r * cellH;
      const rect = svgEl("rect", { x, y, width: cellW - 2, height: cellH - 2, rx: 6, fill: `rgba(58,214,255,${a.toFixed(3)})`, stroke: "rgba(255,255,255,.06)" });
      rect.addEventListener("mousemove", (ev) => {
        showTip(ev.clientX, ev.clientY, "Heatmap", `${rowLabels[r]} • ${colLabels[c]}: ${fmt(v)}`, "Atividade (posts+comentários)");
      });
      rect.addEventListener("mouseleave", hideTip);
      svg.appendChild(rect);
    }
  }

  // labels eixo X
  colLabels.forEach((lab, i) => {
    const t = svgEl("text", { x: padL + i * cellW + cellW / 2, y: h - 6, "text-anchor": "middle", "font-size": "10", fill: "rgba(219,228,255,.70)" });
    t.textContent = lab;
    svg.appendChild(t);
  });
  // labels eixo Y
  rowLabels.forEach((lab, i) => {
    const t = svgEl("text", { x: 6, y: i * cellH + cellH / 2 + 3, "text-anchor": "start", "font-size": "10", fill: "rgba(219,228,255,.70)" });
    t.textContent = lab;
    svg.appendChild(t);
  });

  container.appendChild(svg);
}

function renderFunnel(container, steps) {
  clear(container);
  const max = Math.max(...steps.map((s) => s.value), 1);
  const wrap = document.createElement("div");
  wrap.style.display = "grid";
  wrap.style.gap = "10px";
  steps.forEach((s, i) => {
    const row = document.createElement("div");
    row.style.display = "grid";
    row.style.gridTemplateColumns = "120px 1fr 70px";
    row.style.alignItems = "center";
    row.style.gap = "10px";
    row.style.fontSize = "12px";
    row.style.color = "rgba(219,228,255,.80)";
    const bar = document.createElement("div");
    bar.style.height = "10px";
    bar.style.borderRadius = "999px";
    bar.style.background = "rgba(255,255,255,.08)";
    const fill = document.createElement("div");
    fill.style.height = "10px";
    fill.style.borderRadius = "999px";
    fill.style.width = `${(s.value / max) * 100}%`;
    fill.style.background = i === 0 ? "linear-gradient(90deg, #6f4ff8, #3ad6ff)" : "rgba(111,79,248,.55)";
    bar.appendChild(fill);
    bar.addEventListener("mousemove", (ev) => {
      showTip(ev.clientX, ev.clientY, "Funil", `${s.label}: ${fmt(s.value)}`, `Topo: ${fmt(max)}`);
    });
    bar.addEventListener("mouseleave", hideTip);
    row.innerHTML = `<span>${s.label}</span>`;
    row.appendChild(bar);
    const val = document.createElement("span");
    val.style.textAlign = "right";
    val.textContent = fmt(s.value);
    row.appendChild(val);
    wrap.appendChild(row);
  });
  container.appendChild(wrap);
}

function renderKpiBox(container, label, value, sub) {
  clear(container);
  const div = document.createElement("div");
  div.style.display = "grid";
  div.style.gap = "6px";
  div.innerHTML = `<div style="font-size:11px;color:rgba(219,228,255,.70);letter-spacing:.14em;text-transform:uppercase;">${label}</div>
                   <div style="font-size:26px;font-weight:900;">${value}</div>
                   <div style="font-size:12px;color:rgba(219,228,255,.70);">${sub}</div>`;
  container.appendChild(div);
}

// ====== App ======

const DATA = buildDataset();

function inPeriod(d, days) {
  if (days === "all") return true;
  const n = Number(days);
  if (!n) return true;
  return d >= daysAgo(n);
}

function applyFilters() {
  const period = $("#filter-period")?.value ?? "30";
  const course = $("#filter-course")?.value ?? "all";
  const city = $("#filter-location")?.value ?? "all";

  const posts = DATA.posts.filter((p) => inPeriod(p.created, period) && (course === "all" || p.course === course) && (city === "all" || p.city === city));
  const postIds = new Set(posts.map((p) => p.id));
  const comments = DATA.comments.filter((c) => postIds.has(c.postId));

  const jobs = DATA.jobs.filter((j) => inPeriod(j.created, period) && (city === "all" || j.city === city));
  const jobIds = new Set(jobs.map((j) => j.id));
  const applications = DATA.applications.filter((a) => jobIds.has(a.jobId) && inPeriod(a.created, period) && (course === "all" || a.course === course) && (city === "all" || a.city === city));

  return { period, course, city, posts, comments, jobs, applications };
}

function setKpi(id, value, sub) {
  const box = document.getElementById(id);
  if (!box) return;
  const valEl = box.querySelector(".kpi-value");
  const subEl = document.getElementById(`${id}-sub`) || box.querySelector(".kpi-sub");
  if (valEl) valEl.textContent = value;
  if (subEl) subEl.textContent = sub;
}

function fillFilters() {
  const courseSel = $("#filter-course");
  const locSel = $("#filter-location");
  if (courseSel && !courseSel.options.length) {
    courseSel.innerHTML = `<option value="all">Todos</option>` + DATA.courses.map((c) => `<option value="${c}">${c}</option>`).join("");
  }
  if (locSel && !locSel.options.length) {
    locSel.innerHTML = `<option value="all">Todos</option>` + Array.from(new Set(DATA.cities)).map((c) => `<option value="${c}">${c}</option>`).join("");
  }
}

function updateAll() {
  try {
    const f = applyFilters();

  // ===== Visão Geral (1–7) =====
  setKpi("kpi-total-users", fmt(DATA.users.length), `${fmt(DATA.users.filter((u) => u.is_active === true).length)} ativos (cadastro)`);
  const active30 = new Set(f.posts.map((p) => p.authorId)).size;
  setKpi("kpi-active-users", fmt(active30), `Autores que postaram no período`);
  setKpi("kpi-total-posts", fmt(f.posts.length), `Filtro: ${f.period === "all" ? "todo período" : `${f.period} dias`} • ${f.course === "all" ? "todos cursos" : f.course}`);
  setKpi("kpi-total-comments", fmt(f.comments.length), `Média: ${fmt1(f.posts.length ? f.comments.length / f.posts.length : 0)} por post`);

  // atividade diária
  const byDay = new Map();
  f.posts.forEach((p) => byDay.set(isoDay(p.created), (byDay.get(isoDay(p.created)) || 0) + 1));
  f.comments.forEach((c) => byDay.set(isoDay(c.created), (byDay.get(isoDay(c.created)) || 0) + 1));
  const days = Array.from(byDay.keys()).sort();
  const daily = days.map((d) => ({ label: d.slice(5), value: byDay.get(d) }));
  renderLine($("#chart-activity-daily"), daily);

  // overview extra: top cursos ativos
  const byCourse = new Map();
  f.posts.forEach((p) => byCourse.set(p.course, (byCourse.get(p.course) || 0) + 1));
  const topCourses = Array.from(byCourse.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 6)
    .map(([label, value]) => ({ label: label.slice(0, 10), value }));
  renderBars($("#chart-overview-courses"), topCourses);

  // distribuição de posts por curso (pizza) e por cidade (barra) e visibilidade
  const postsByCourseTotal = Array.from(byCourse.entries()).map(([label, value]) => ({ label: label.split(" ")[0], value }));
  renderDonut($("#chart-overview-posts-by-course"), postsByCourseTotal);

  const byCity = new Map();
  f.posts.forEach((p) => byCity.set(p.city, (byCity.get(p.city) || 0) + 1));
  const postsByCity = Array.from(byCity.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([label, value]) => ({ label: label.slice(0, 8), value }));
  renderBars($("#chart-overview-posts-by-city"), postsByCity);

  const visPublic = f.posts.filter((p) => p.visibility === "public").length;
  const visPrivate = f.posts.length - visPublic;
  renderDonut($("#chart-overview-visibility"), [
    { label: "Público", value: visPublic },
    { label: "Privado", value: visPrivate },
  ]);

  // funil vagas
  const views = f.jobs.reduce((s, j) => s + j.views, 0);
  const applies = f.jobs.reduce((s, j) => s + j.applies, 0);
  const interviews = f.jobs.reduce((s, j) => s + j.interviews, 0);
  const hires = f.jobs.reduce((s, j) => s + j.hires, 0);
  renderFunnel($("#chart-jobs-funnel"), [
    { label: "Views", value: views },
    { label: "Applies", value: applies },
    { label: "Entrev.", value: interviews },
    { label: "Hires", value: hires },
  ]);

  // engajamento (interações/post)
  const likes = f.posts.reduce((s, p) => s + p.likes, 0);
  const shares = f.posts.reduce((s, p) => s + p.shares, 0);
  const interactions = likes + shares + f.comments.length;
  const perPost = f.posts.length ? interactions / f.posts.length : 0;
  renderKpiBox($("#chart-engagement-rate"), "Interações / post", fmt1(perPost), `${fmt(interactions)} interações no período`);

  // overview extras (KPIs)
  setKpi("kpi-overview-engagement", fmt(interactions), `${fmt1(perPost)} interações/post (likes + shares + comentários)`);
  setKpi("kpi-overview-jobs", fmt(f.jobs.length), `${fmt(applies)} candidaturas • ${fmt(hires)} contratações (período)`);
  const coursesWithPosts = new Set(f.posts.map((p) => p.course));
  setKpi("kpi-overview-courses", fmt(coursesWithPosts.size), "Cursos com atividade no recorte atual");
  const langCountsGlobal = new Map();
  DATA.users.forEach((u) => {
    const l = u.language || "pt-BR";
    langCountsGlobal.set(l, (langCountsGlobal.get(l) || 0) + 1);
  });
  const domLang = Array.from(langCountsGlobal.entries()).sort((a, b) => b[1] - a[1])[0];
  setKpi("kpi-overview-language", domLang ? domLang[0] : "—", domLang ? `${fmt(domLang[1])} perfis` : "Sem idioma definido");

  // tabela resumo rápido (Top 5 indicadores)
  const top5Body = $("#table-overview-top5 tbody");
  if (top5Body) {
    const indicators = [
      ["Posts (período)", fmt(f.posts.length)],
      ["Comentários (período)", fmt(f.comments.length)],
      ["Interações totais", fmt(interactions)],
      ["Vagas ativas", fmt(f.jobs.filter((j) => j.status === "open").length)],
      ["Cursos com atividade", fmt(coursesWithPosts.size)],
    ];
    top5Body.innerHTML = indicators.map(([k, v]) => `<tr><td>${k}</td><td>${v}</td></tr>`).join("");
  }

  // alertas gerais no overview (high-level)
  const overviewAlerts = $("#overview-alerts");
  if (overviewAlerts) {
    const alerts = [];
    if (perPost < 15) alerts.push({ t: "Engajamento baixo", p: "Média de interações/post poderia estar mais alta. Vale testar desafio geral da semana." });
    if (f.jobs.filter((j) => j.status === "open").length === 0) alerts.push({ t: "Poucas vagas ativas", p: "Nenhuma vaga aberta no recorte atual. Sugestão: publicar pelo menos 2 por área forte." });
    if (!alerts.length) alerts.push({ t: "Saúde ok", p: "Sem alertas críticos gerais. Olhe os detalhes em Engajamento e RAI para ajustes finos." });
    overviewAlerts.innerHTML = alerts.map((x) => `<div class="rai-item"><strong>${x.t}</strong><p>${x.p}</p></div>`).join("");
  }

  // ===== Engajamento (8–13) =====
  const byHourPosts = Array.from({ length: 24 }, (_, h) => ({ label: String(h).padStart(2, "0"), value: 0 }));
  f.posts.forEach((p) => (byHourPosts[p.created.getHours()].value += 1));
  renderBars($("#chart-posts-hour"), byHourPosts.slice(8, 20));

  const byHourComments = Array.from({ length: 24 }, (_, h) => ({ label: String(h).padStart(2, "0"), value: 0 }));
  f.comments.forEach((c) => (byHourComments[c.created.getHours()].value += 1));
  renderBars($("#chart-comments-hour"), byHourComments.slice(8, 20));

  clear($("#chart-posts-comments-ratio"));
  $("#chart-posts-comments-ratio").textContent = `Posts: ${fmt(f.posts.length)} • Comentários: ${fmt(f.comments.length)} • ${fmt1(f.posts.length ? f.comments.length / f.posts.length : 0)} com./post`;

  // likes/shares por dia
  const likesByDay = new Map();
  const sharesByDay = new Map();
  f.posts.forEach((p) => {
    const k = isoDay(p.created);
    likesByDay.set(k, (likesByDay.get(k) || 0) + p.likes);
    sharesByDay.set(k, (sharesByDay.get(k) || 0) + p.shares);
  });
  const days2 = Array.from(new Set([...likesByDay.keys(), ...sharesByDay.keys()])).sort();
  renderLine($("#chart-likes-daily"), days2.map((d) => ({ label: d.slice(5), value: likesByDay.get(d) || 0 })), { stroke: "#3ad6ff" });
  renderLine($("#chart-shares-daily"), days2.map((d) => ({ label: d.slice(5), value: sharesByDay.get(d) || 0 })), { stroke: "#6f4ff8" });

  renderDonut($("#chart-interactions-type"), [
    { label: "Likes", value: likes },
    { label: "Shares", value: shares },
    { label: "Comentários", value: f.comments.length },
  ]);

  // ===== Conteúdo (14–21) =====
  const postsWithText = f.posts.filter((p) => p.text && p.text.trim().length).length;
  const postsNoText = f.posts.length - postsWithText;
  setKpi("kpi-posts-with-text", fmt(postsWithText), `${fmt1(f.posts.length ? (postsWithText * 100) / f.posts.length : 0)}%`);
  setKpi("kpi-posts-without-text", fmt(postsNoText), `Texto vazio/sem conteúdo`);
  setKpi("kpi-avg-comments-post", fmt1(f.posts.length ? f.comments.length / f.posts.length : 0), `~${fmt1(perPost)} interações/post`);

  const langCounts = new Map();
  DATA.users.forEach((u) => {
    const l = u.language || "pt-BR";
    langCounts.set(l, (langCounts.get(l) || 0) + 1);
  });
  setKpi("kpi-langs", fmt(new Set(DATA.users.map((u) => u.language || "pt-BR")).size), `Base: idiomas de perfil`);

  const postLang = new Map();
  f.posts.forEach((p) => {
    const author = DATA.users.find((u) => u.id === p.authorId);
    const l = author?.language || "pt-BR";
    postLang.set(l, (postLang.get(l) || 0) + 1);
  });
  renderBars($("#chart-lang-posts"), Array.from(postLang.entries()).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value));

  const lens = f.posts.filter((p) => typeof p.text === "string").map((p) => p.text.length);
  const avgLen = lens.length ? lens.reduce((a, b) => a + b, 0) / lens.length : 0;
  renderKpiBox($("#chart-text-length"), "Média de caracteres", fmt1(avgLen), `${fmt(lens.length)} posts com texto`);

  const tagCounts = new Map();
  f.posts.forEach((p) => p.tags.forEach((t) => tagCounts.set(t, (tagCounts.get(t) || 0) + 1)));
  renderBars($("#chart-top-tags"), Array.from(tagCounts.entries()).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value).slice(0, 10));

  // tabela posts em alta
  const commByPost = new Map();
  f.comments.forEach((c) => commByPost.set(c.postId, (commByPost.get(c.postId) || 0) + 1));
  const topPosts = f.posts
    .map((p) => {
      const c = commByPost.get(p.id) || 0;
      const score = p.likes + p.shares * 2 + c * 3;
      return { ...p, comments: c, score };
    })
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
  const topPostsTbody = $("#table-top-posts tbody");
  if (topPostsTbody) {
    topPostsTbody.innerHTML = topPosts
      .map((p) => `<tr><td>${(p.text || "Sem texto").slice(0, 36)}${p.text && p.text.length > 36 ? "…" : ""}</td><td>${p.course}</td><td>${fmt(p.likes)}</td><td>${fmt(p.comments)}</td><td>${fmt(p.score)}</td></tr>`)
      .join("");
  }

  // ===== Pessoas (22–27) =====
  const gender = new Map();
  DATA.users.forEach((u) => gender.set(u.gender || "indef.", (gender.get(u.gender || "indef.") || 0) + 1));
  setKpi("kpi-gender-distribution", `${fmt(gender.get("male") || 0)} M • ${fmt(gender.get("female") || 0)} F`, `${fmt(DATA.users.length - (gender.get("male") || 0) - (gender.get("female") || 0))} outros/ND`);
  setKpi("kpi-can-publish", fmt(DATA.users.filter((u) => u.can_publish === true).length), `${fmt1((DATA.users.filter((u) => u.can_publish === true).length * 100) / DATA.users.length)}%`);
  const userLang = new Map();
  DATA.users.forEach((u) => userLang.set(u.language || "pt-BR", (userLang.get(u.language || "pt-BR") || 0) + 1));
  setKpi("kpi-lang-users", fmt(userLang.size), Array.from(userLang.entries()).map(([l, c]) => `${l}:${c}`).slice(0, 3).join(" • "));
  renderBars($("#chart-user-lang"), Array.from(userLang.entries()).map(([label, value]) => ({ label, value })).sort((a, b) => b.value - a.value));
  renderBars($("#chart-user-gender"), Array.from(gender.entries()).map(([label, value]) => ({ label: label === "male" ? "M" : label === "female" ? "F" : "ND", value })));

  // score por usuário (período)
  const score = new Map();
  DATA.users.forEach((u) => score.set(u.id, 0));
  f.posts.forEach((p) => score.set(p.authorId, score.get(p.authorId) + (p.likes * 0.6 + p.shares * 1.6 + 8)));
  f.comments.forEach((c) => score.set(c.authorId, score.get(c.authorId) + 4));
  f.applications.forEach((a) => score.set(a.userId, score.get(a.userId) + (a.stage === "hired" ? 35 : a.stage === "interview" ? 12 : 6)));
  const scoredUsers = DATA.users
    .map((u) => ({ u, score: Math.round(score.get(u.id)), level: Math.max(1, Math.floor(Math.sqrt(score.get(u.id)) / 6)) }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 12);
  const topUsersTbody = $("#table-top-users tbody");
  if (topUsersTbody) {
    topUsersTbody.innerHTML = scoredUsers
      .map((x) => `<tr><td>${x.u.username || "-"}</td><td>${x.u.name}</td><td>${x.u.course}</td><td>${fmt(x.score)}</td><td>Nível ${x.level}</td></tr>`)
      .join("");
  }

  // ===== Vagas (28–34) =====
  const openJobs = DATA.jobs.filter((j) => j.status === "open").length;
  setKpi("kpi-jobs-open", fmt(openJobs), `${fmt(DATA.jobs.length)} no total`);
  setKpi("kpi-applications", fmt(f.applications.length), `No período selecionado`);
  const interviewsP = f.applications.filter((a) => a.stage === "interview" || a.stage === "hired").length;
  const hiresP = f.applications.filter((a) => a.stage === "hired").length;
  setKpi("kpi-interviews", fmt(interviewsP), `${fmt1(f.applications.length ? (interviewsP * 100) / f.applications.length : 0)}% do funil`);
  setKpi("kpi-hires", fmt(hiresP), `${fmt1(f.applications.length ? (hiresP * 100) / f.applications.length : 0)}% do funil`);

  const byArea = new Map();
  f.jobs.forEach((j) => byArea.set(j.area, (byArea.get(j.area) || 0) + 1));
  renderBars($("#chart-jobs-by-area"), Array.from(byArea.entries()).map(([label, value]) => ({ label: label.slice(0, 8), value })).sort((a, b) => b.value - a.value));

  const appByDay = new Map();
  f.applications.forEach((a) => appByDay.set(isoDay(a.created), (appByDay.get(isoDay(a.created)) || 0) + 1));
  const appDays = Array.from(appByDay.keys()).sort();
  renderLine($("#chart-applications-daily"), appDays.map((d) => ({ label: d.slice(5), value: appByDay.get(d) })), { stroke: "#45e39a" });

  const topJobs = f.jobs
    .map((j) => ({ ...j, conv: j.views ? j.applies / j.views : 0 }))
    .sort((a, b) => b.applies - a.applies)
    .slice(0, 10);
  const topJobsTbody = $("#table-top-jobs tbody");
  if (topJobsTbody) {
    topJobsTbody.innerHTML = topJobs
      .map((j) => `<tr><td>${j.title}</td><td>${j.company}</td><td>${j.area}</td><td>${fmt(j.views)}</td><td>${fmt(j.applies)}</td></tr>`)
      .join("");
  }

  // ===== Localização (35–39) =====
  setKpi("kpi-total-locations", fmt(baseLocations.length), "País/UF/cidades (amostra)");
  const states = new Set(baseLocations.map((l) => l["place-id"]).filter((id) => /^BR-[A-Z]{2}$/.test(id)));
  const cities = new Set(baseLocations.map((l) => l["place-id"]).filter((id) => id.split("-").length >= 3));
  setKpi("kpi-states", fmt(states.size), Array.from(states).slice(0, 5).join(", "));
  setKpi("kpi-cities", fmt(cities.size), `${Array.from(cities).slice(0, 3).join(", ")}${cities.size > 3 ? "…" : ""}`);

  const cityAct = new Map();
  f.posts.forEach((p) => cityAct.set(p.city, (cityAct.get(p.city) || 0) + 1));
  renderBars($("#chart-locations"), Array.from(cityAct.entries()).map(([label, value]) => ({ label: label.slice(0, 8), value })).sort((a, b) => b.value - a.value).slice(0, 10));

  renderDonut($("#chart-location-types"), [
    { label: "UF", value: states.size },
    { label: "Cidades", value: cities.size },
    { label: "Base", value: 1 },
  ]);

  // Mapa (cidades principais)
  const coords = {
    "São Paulo": { lat: -23.55, lon: -46.63 },
    "Campinas": { lat: -22.90, lon: -47.06 },
    "Santos": { lat: -23.96, lon: -46.33 },
    "Rio de Janeiro": { lat: -22.91, lon: -43.17 },
    "Belo Horizonte": { lat: -19.92, lon: -43.94 },
    "Curitiba": { lat: -25.43, lon: -49.27 },
    "Porto Alegre": { lat: -30.03, lon: -51.23 },
    "Brasília": { lat: -15.79, lon: -47.88 },
    "Salvador": { lat: -12.97, lon: -38.50 },
    "Recife": { lat: -8.05, lon: -34.88 },
    "Fortaleza": { lat: -3.73, lon: -38.52 },
  };

  const mapPoints = Array.from(cityAct.entries())
    .filter(([city]) => coords[city])
    .map(([city, value]) => ({ label: city, value, ...coords[city] }))
    .sort((a, b) => b.value - a.value)
    .slice(0, 10);
  renderBrazilMap($("#chart-map"), mapPoints);

  // ===== RAI (46+) =====
  renderRai(f, {
    likes,
    shares,
    interactions,
    perPost,
    activeAuthors: new Set(f.posts.map((p) => p.authorId)).size,
  });

  // ===== Perfil & Gamificação (40–45) =====
  // Perfil demo: usa o primeiro usuário ativo como "logado"
  const me = DATA.users.find((u) => u.is_active === true) || DATA.users[0];
  const meScore = Math.round(score.get(me.id) || 0);
  const meLevel = Math.max(1, Math.floor(Math.sqrt(meScore) / 6));
  const sameCourse = DATA.users.filter((u) => u.course === me.course);
  const ranking = sameCourse
    .map((u) => ({ u, pts: Math.round(score.get(u.id) || 0) }))
    .sort((a, b) => b.pts - a.pts);
  const myRank = ranking.findIndex((r) => r.u.id === me.id) + 1;

  setKpi("kpi-my-level", `Nível ${meLevel}`, `${me.name} • ${me.course}`);
  setKpi("kpi-my-score", fmt(meScore), `Likes+shares+comentários+vagas (demo)`);
  setKpi("kpi-my-rank", `#${myRank}`, `Entre ${fmt(ranking.length)} do curso`);

  const globalRank = DATA.gamification
    .slice()
    .sort((a, b) => b.points - a.points)
    .slice(0, 10)
    .map((g) => {
      const u = DATA.users.find((x) => x.id === g.userId);
      return { user: u, points: g.points, course: g.course, level: g.level };
    });
  const tbodyRank = $("#table-course-ranking tbody");
  if (tbodyRank) {
    tbodyRank.innerHTML = globalRank
      .map((r, i) => `<tr><td>#${i + 1}</td><td>${r.user?.name || "-"}</td><td>${r.course}</td><td>${fmt(r.points)}</td></tr>`)
      .join("");
  }

  const levelDist = new Map();
  DATA.gamification.forEach((g) => levelDist.set(`L${g.level}`, (levelDist.get(`L${g.level}`) || 0) + 1));
  renderBars($("#chart-level-distribution"), Array.from(levelDist.entries()).map(([label, value]) => ({ label, value })).sort((a, b) => a.label.localeCompare(b.label)));

  const badges = [
    { name: "Mentor(a) do mês", desc: "Ajudou 10+ colegas", color: "#3ad6ff" },
    { name: "Top candidato(a)", desc: "3 candidaturas aprovadas", color: "#45e39a" },
    { name: "Criador(a) constante", desc: "Publicou em 4 semanas seguidas", color: "#6f4ff8" },
    { name: "Engajamento premium", desc: "Média 25+ interações/post", color: "#ffb24a" },
    { name: "Networking", desc: "Conectou com 15 perfis", color: "#ff4f74" },
  ];
  const badgesEl = $("#badges");
  if (badgesEl) {
    badgesEl.innerHTML = badges
      .map((b) => `<span class="badge" style="border-color:rgba(255,255,255,.14);background:rgba(255,255,255,.06)"><strong style="color:${b.color};font-weight:900;margin-right:6px;">●</strong>${b.name} <span style="color:rgba(219,228,255,.70)">— ${b.desc}</span></span>`)
      .join("");
  }

  // UI meta
  const last = $("#last-refresh");
  if (last) last.textContent = new Date().toLocaleString("pt-BR");
  } catch (err) {
    console.error("updateAll falhou:", err);
  }
}

function renderRai(f, ctx) {
  // Heurísticas simples + texto "RAI" (demo)
  const byDayPosts = new Map();
  const byDayComments = new Map();
  f.posts.forEach((p) => byDayPosts.set(isoDay(p.created), (byDayPosts.get(isoDay(p.created)) || 0) + 1));
  f.comments.forEach((c) => byDayComments.set(isoDay(c.created), (byDayComments.get(isoDay(c.created)) || 0) + 1));
  const days = Array.from(new Set([...byDayPosts.keys(), ...byDayComments.keys()])).sort();
  const series = days.map((d) => ({
    label: d.slice(5),
    value: (byDayPosts.get(d) || 0) + (byDayComments.get(d) || 0),
  }));

  const last7 = series.slice(-7);
  const prev7 = series.slice(-14, -7);
  const sum = (arr) => arr.reduce((s, x) => s + x.value, 0);
  const s7 = sum(last7);
  const p7 = sum(prev7) || 1;
  const wow = ((s7 - p7) / p7) * 100;

  const signal =
    wow > 18 ? "Tá pegando fogo" :
    wow < -12 ? "Deu uma esfriada" :
    "Tá de boa";

  const risk =
    ctx.activeAuthors < Math.max(6, Math.round(DATA.users.length * 0.08)) ? "Pouca gente puxando o bonde" :
    ctx.perPost < 18 ? "Engajamento baixo" :
    "Tudo sob controle";

  // previsão simples: média diária * 30
  const avgDaily = series.length ? sum(series) / series.length : 0;
  const forecast30 = Math.round(avgDaily * 30);

  const jobsOpen = DATA.jobs.filter((j) => j.status === "open").length;
  const pipeline = {
    views: f.jobs.reduce((s, j) => s + j.views, 0),
    applies: f.jobs.reduce((s, j) => s + j.applies, 0),
  };
  const conv = pipeline.views ? (pipeline.applies / pipeline.views) * 100 : 0;

  setKpi("kpi-rai-signal", signal, `${wow >= 0 ? "+" : ""}${fmt1(wow)}% na semana (vs semana passada)`);
  setKpi("kpi-rai-risk", risk, `${fmt(ctx.activeAuthors)} pessoas postando no período`);
  setKpi("kpi-rai-forecast", fmt(forecast30), `Chute honesto: ${fmt1(avgDaily)} interações/dia`);

  // Banner (pills)
  const banner = $("#rai-banner-body");
  if (banner) {
    banner.innerHTML = [
      `<span class="rai-pill"><strong>Clima:</strong> ${signal}</span>`,
      `<span class="rai-pill"><strong>Risco:</strong> ${risk}</span>`,
      `<span class="rai-pill"><strong>Interações:</strong> ${fmt(ctx.interactions)}</span>`,
      `<span class="rai-pill"><strong>Interações/post:</strong> ${fmt1(ctx.perPost)}</span>`,
      `<span class="rai-pill"><strong>Conversão vagas:</strong> ${fmt1(conv)}%</span>`,
    ].join("");
  }

  const topCourses = new Map();
  f.posts.forEach((p) => topCourses.set(p.course, (topCourses.get(p.course) || 0) + 1));
  const topCourse = Array.from(topCourses.entries()).sort((a, b) => b[1] - a[1])[0];

  const topTags = new Map();
  f.posts.forEach((p) => p.tags.forEach((t) => topTags.set(t, (topTags.get(t) || 0) + 1)));
  const topTag = Array.from(topTags.entries()).sort((a, b) => b[1] - a[1])[0];

  const insightsEl = $("#rai-insights");
  if (insightsEl) {
    insightsEl.innerHTML = [
      {
        t: "Leitura 1",
        p: `Tá assim: ${signal}. Na prática, a rede variou ${wow >= 0 ? "+" : ""}${fmt1(wow)}% na última semana.`,
      },
      {
        t: "Leitura 2",
        p: `O assunto que tá bombando é “${topTag ? topTag[0] : "—"}”. Bora surfar isso com posts oficiais e desafios rápidos.`,
      },
      {
        t: "Leitura 3",
        p: `Quem tá mais ativo é ${topCourse ? `${topCourse[0]} (${fmt(topCourse[1])} posts)` : "—"}. Se quer tração, começa por esse curso.`,
      },
      {
        t: "Leitura 4",
        p: `Vagas: ${fmt(jobsOpen)} abertas. Conversão views→candidatura tá em ${fmt1(conv)}%. Dá pra subir com vagas mais específicas por curso.`,
      },
      {
        t: "Leitura 5",
        p: `Se continuar nesse ritmo, dá ~${fmt(forecast30)} interações nos próximos 30 dias. Se lançar desafio + ranking, sobe fácil.`,
      },
    ]
      .map((x) => `<div class="rai-item"><strong>${x.t}</strong><p>${x.p}</p></div>`)
      .join("");
  }

  const actionsEl = $("#rai-actions");
  if (actionsEl) {
    actionsEl.innerHTML = [
      {
        t: "O que fazer agora",
        p: `Lança um “Desafio da Semana” por curso: pontos por comentário útil, +bônus por ajudar alguém com material/explicação.`,
      },
      {
        t: "O que fazer agora",
        p: `Cria vagas de “Monitoria” e “Pesquisa” pros cursos mais ativos. Isso vira ponte direta entre estudo e oportunidade.`,
      },
      {
        t: "O que fazer agora",
        p: `Posta nos picos (10–12 / 14–16) e usa as tags do momento (“${topTag ? topTag[0] : "sql"}”).`,
      },
      {
        t: "O que fazer agora",
        p: `Ativa “Top Contributors” por curso no perfil. A galera compete de um jeito saudável e a retenção sobe.`,
      },
    ]
      .map((x) => `<div class="rai-item"><strong>${x.t}</strong><p>${x.p}</p></div>`)
      .join("");
  }

  // Radar (linha) — reaproveita série de atividade
  renderLine($("#chart-rai-radar"), series.slice(-30));

  // Heatmap (dias da semana x faixas de hora)
  const dow = ["Seg", "Ter", "Qua", "Qui", "Sex", "Sáb", "Dom"];
  const hourBins = ["08–10", "10–12", "12–14", "14–16", "16–18", "18–20"];
  const mat = Array.from({ length: 7 }, () => Array.from({ length: hourBins.length }, () => 0));
  const binIndex = (h) => (h < 10 ? 0 : h < 12 ? 1 : h < 14 ? 2 : h < 16 ? 3 : h < 18 ? 4 : 5);
  f.posts.forEach((p) => {
    const d = p.created.getDay(); // 0 dom
    const r = d === 0 ? 6 : d - 1;
    mat[r][binIndex(p.created.getHours())] += 1;
  });
  f.comments.forEach((c) => {
    const d = c.created.getDay();
    const r = d === 0 ? 6 : d - 1;
    mat[r][binIndex(c.created.getHours())] += 1;
  });
  renderHeatmap($("#chart-rai-heatmap"), mat, dow, hourBins);

  // Movers (tags) — 7d vs 7d
  const cutoff7 = daysAgo(7);
  const cutoff14 = daysAgo(14);
  const tag7 = new Map();
  const tagPrev = new Map();
  DATA.posts.forEach((p) => {
    if (f.course !== "all" && p.course !== f.course) return;
    if (f.city !== "all" && p.city !== f.city) return;
    if (p.created >= cutoff7) {
      p.tags.forEach((t) => tag7.set(t, (tag7.get(t) || 0) + 1));
    } else if (p.created >= cutoff14) {
      p.tags.forEach((t) => tagPrev.set(t, (tagPrev.get(t) || 0) + 1));
    }
  });
  const movers = Array.from(new Set([...tag7.keys(), ...tagPrev.keys()]))
    .map((t) => {
      const a = tag7.get(t) || 0;
      const b = tagPrev.get(t) || 0;
      return { label: t, value: a - b, a, b };
    })
    .sort((x, y) => Math.abs(y.value) - Math.abs(x.value))
    .slice(0, 10)
    .map((m) => ({ label: m.label.slice(0, 8), value: Math.abs(m.value) || 1 }));
  renderBars($("#chart-rai-movers"), movers);

  // Qualidade (donut): texto / sem texto / privado
  const withText = f.posts.filter((p) => p.text && p.text.trim().length).length;
  const noText = f.posts.length - withText;
  const priv = f.posts.filter((p) => p.visibility === "private").length;
  renderDonut($("#chart-rai-quality"), [
    { label: "Com texto", value: withText },
    { label: "Sem texto", value: noText },
    { label: "Privado", value: priv },
  ]);

  // Watchlist
  const watch = $("#rai-watchlist");
  if (watch) {
    const flags = [];
    if (ctx.activeAuthors < Math.max(6, Math.round(DATA.users.length * 0.08))) flags.push({ t: "Alerta", p: "Participação concentrada: chama embaixadores do curso e ativa meta de comentários úteis." });
    if (ctx.perPost < 18) flags.push({ t: "Alerta", p: "Engajamento baixo: posta nos picos e fixa um tópico semanal com recompensa." });
    if (conv < 4) flags.push({ t: "Alerta", p: "Vagas com conversão baixa: ajuste título/área e encaixe curso + cidade no texto." });
    if (!flags.length) flags.push({ t: "Tudo ok", p: "Sem alertas críticos no recorte atual. Mantém o ritmo e testa pequenas melhorias." });
    watch.innerHTML = flags.map((x) => `<div class="rai-item"><strong>${x.t}</strong><p>${x.p}</p></div>`).join("");
  }

  // TL;DR
  const tldr = $("#rai-tldr");
  if (tldr) {
    const line1 = `Clima: ${signal}. Interações/post: ${fmt1(ctx.perPost)}.`;
    const line2 = `Curso em destaque: ${topCourse ? topCourse[0] : "—"}. Tag do momento: ${topTag ? topTag[0] : "—"}.`;
    const line3 = `Próximos 30 dias: ~${fmt(forecast30)} interações (cenário base).`;
    tldr.innerHTML = [
      { t: "Resumo", p: line1 },
      { t: "Foco", p: line2 },
      { t: "Previsão", p: line3 },
    ].map((x) => `<div class="rai-item"><strong>${x.t}</strong><p>${x.p}</p></div>`).join("");
  }

  // Cenários
  const scenarios = [
    { name: "Base", mult: 1.0, note: "Mantém ritmo atual" },
    { name: "Com desafio por curso", mult: 1.18, note: "Mais comentários e retenção" },
    { name: "Com vagas hiper-segmentadas", mult: 1.10, note: "Mais conversão e posts de oportunidade" },
    { name: "Semana difícil (provas)", mult: 0.88, note: "Menos tempo no app" },
  ];
  const scenBody = $("#table-rai-scenarios tbody");
  if (scenBody) {
    scenBody.innerHTML = scenarios.map((s) => {
      const v = Math.round(forecast30 * s.mult);
      return `<tr><td>${s.name}</td><td>${fmt(v)}</td><td>${s.note}</td></tr>`;
    }).join("");
  }

  // Oportunidades por curso (heurística)
  const byCourse = new Map();
  f.posts.forEach((p) => byCourse.set(p.course, (byCourse.get(p.course) || 0) + 1));
  const opp = Array.from(byCourse.entries())
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([courseName, count]) => {
      const tag = topTag ? topTag[0] : "sql";
      const s = count > 40 ? "Alta" : count > 22 ? "Média" : "Baixa";
      const reason = s === "Alta" ? `Turma ativa; dá pra puxar vagas + conteúdos em “${tag}”.` :
        s === "Média" ? "Bom potencial; um desafio semanal destrava participação." :
        "Baixa atividade; precisa de embaixadores + posts oficiais fixados.";
      return { courseName, s, reason };
    });
  const oppBody = $("#table-rai-opportunities tbody");
  if (oppBody) {
    oppBody.innerHTML = opp.map((o) => `<tr><td>${o.courseName}</td><td>${o.s}</td><td>${o.reason}</td></tr>`).join("");
  }
}

function showPanel(panelId, title, subtitle) {
  $all(".section").forEach((s) => (s.id === panelId ? s.classList.remove("panel-hidden") : s.classList.add("panel-hidden")));
  $("#page-title").textContent = title;
  $("#page-subtitle").textContent = subtitle;

  // Re-render após trocar painel (evita gráficos vazios por largura 0)
  requestAnimationFrame(() => {
    updateAll();
  });
}

function setupNav() {
  const meta = {
    "panel-overview": ["Visão Geral", "Indicadores-chave da rede acadêmica e de vagas."],
    "panel-engajamento": ["Engajamento", "Interações, horários de pico e comportamento no período."],
    "panel-conteudo": ["Conteúdo", "Qualidade do feed, tópicos e performance por posts."],
    "panel-pessoas": ["Pessoas", "Perfis, distribuição e top rankings por score."],
    "panel-vagas": ["Vagas", "Pipeline, conversão e áreas mais demandadas."],
    "panel-localizacao": ["Localização", "Atividade por cidade e distribuição geográfica."],
    "panel-rai": ["Análise do RAI", "Leituras e previsões geradas a partir do comportamento da rede."],
    "panel-perfil": ["Perfil", "Gamificação e ranking por curso (demo)."],
  };

  $all(".nav-item").forEach((btn) => {
    btn.addEventListener("click", () => {
      $all(".nav-item").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      const panel = btn.getAttribute("data-panel") || "panel-overview";
      const [t, s] = meta[panel] || meta["panel-overview"];
      showPanel(panel, t, s);
      requestAnimationFrame(() => updateAll());
    });
  });

  showPanel("panel-overview", ...meta["panel-overview"]);
}

function setupFilters() {
  ["#filter-period", "#filter-course", "#filter-location"].forEach((id) => {
    const el = $(id);
    if (!el) return;
    el.addEventListener("change", () => updateAll());
  });
}

function setAuthed(isAuthed, username = "admin") {
  const auth = $("#auth-screen");
  const app = $("#app");
  if (isAuthed) {
    auth.classList.add("hidden");
    app.classList.remove("hidden");
    $("#session-user").textContent = username;
    fillFilters();
    updateAll();
  } else {
    auth.classList.remove("hidden");
    app.classList.add("hidden");
  }
}

function setupAuth() {
  const stored = localStorage.getItem(AUTH_KEY);
  if (stored === "1") setAuthed(true, "admin");

  $("#login-form").addEventListener("submit", (e) => {
    e.preventDefault();
    const user = $("#login-user").value.trim();
    const pass = $("#login-pass").value.trim();
    const err = $("#login-error");
    if (user === AUTH.user && pass === AUTH.pass) {
      localStorage.setItem(AUTH_KEY, "1");
      err.textContent = "";
      setAuthed(true, user);
    } else {
      err.textContent = "Usuário ou senha inválidos.";
    }
  });

  $("#logout-btn").addEventListener("click", () => {
    localStorage.removeItem(AUTH_KEY);
    setAuthed(false);
  });
}

window.addEventListener("DOMContentLoaded", () => {
  setupAuth();
  setupNav();
  setupFilters();
});


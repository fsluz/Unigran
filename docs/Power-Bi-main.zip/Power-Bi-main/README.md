# UNIGRAM Analytics – Painel estilo Power BI

Este projeto é um protótipo de painel analítico para a UNIGRAM, uma rede social acadêmica com vagas e funcionalidades parecidas com o LinkedIn, pensado para uso interno (coordenação, carreira, marketing, etc.). A ideia foi simular como seria um “Power BI” rodando direto no navegador, sem precisar de servidor ou banco de dados.

Tudo é feito em três arquivos:

- `index.html` – estrutura da aplicação (login + layout dos painéis);
- `style.css` – visual escuro, mais próximo de dashboard moderno;
- `app.js` – geração dos dados fictícios, lógica dos filtros e renderização dos gráficos.

Não há dependências externas. Os gráficos são desenhados “na mão” com SVG e JavaScript, justamente para não depender de bibliotecas de chart.

---

## Como usar

1. Abra a pasta `POWER BI`.
2. Dê duplo clique no arquivo `index.html`.
3. Na tela de login use:
   - **Usuário:** `admin`
   - **Senha:** `admin`
4. Depois de logado, use o menu lateral para navegar entre os painéis.

> Obs.: tudo roda somente no navegador. Não é preciso instalar nada além de um browser minimamente recente.

---

## Estrutura dos painéis

### 1. Visão Geral

Painel principal, pensado para alguém que quer bater o olho e entender “como está a rede hoje” sem ficar abrindo aba por aba.

Algumas das leituras que dá para tirar daqui:

- Quantidade total de usuários e quantos de fato estão ativos no período.
- Quantos posts e comentários foram feitos no recorte atual (por padrão, últimos 30 dias).
- Interações totais (likes + compartilhamentos + comentários) e média de interações por post.
- Como está o funil de vagas (views → candidaturas → entrevistas → contratações).
- Quais cursos estão gerando mais movimento.
- Distribuição de posts por curso, por cidade e por tipo de visibilidade (público x privado).
- Uma pequena tabela de “Resumo rápido” com os 5 números principais.
- Um bloco de “Alertas gerais” quando algo destoa (engajamento baixo, poucas vagas ativas, etc.).

### 2. Engajamento

Focado em quando e como a rede se mexe. É útil para decisões de comunicação e calendário.

Aqui entram, por exemplo:

- Posts por hora do dia;
- Comentários por hora do dia;
- Comparativo simples de volume de posts x comentários;
- Evolução diária de likes e de compartilhamentos;
- Distribuição das interações por tipo (curtida, share, comentário).

Os cards aceitariam facilmente mais métricas se um dia entrar dado real (por exemplo, alcance ou tempo médio de leitura).

### 3. Conteúdo

Painel voltado para quem cuida do feed em si.

Tem coisas do tipo:

- Quantos posts vêm com texto “de verdade” e quantos são praticamente em branco;
- Idiomas dos posts (e quais dominam);
- Tamanho médio dos textos;
- Tags/tópicos que mais aparecem;
- Uma lista de posts em alta, com score baseado em likes, shares e comentários.

É uma forma rápida de enxergar se o conteúdo está mais raso, repetitivo ou se está surgindo alguma pauta interessante.

### 4. Pessoas

Aqui a lente vira para os perfis:

- Distribuição de gênero;
- Idioma de perfil;
- Quem pode publicar (e quem só consome);
- Usuários por idioma e por gênero em barra;
- Ranking dos perfis com melhor “score” no período (mistura atividade no feed e interação com vagas).

Esse painel conversa bem com ações de embaixadores, mentores, campanhas internas etc.

### 5. Vagas

Mais voltado para estágio/empregabilidade:

- Quantas vagas estão abertas no recorte atual;
- Candidaturas, entrevistas e contratações no período;
- Vagas por área (Tecnologia, Dados, Saúde, etc.);
- Candidaturas por dia;
- Uma tabela de top vagas com maior alcance e conversão.

É quase um “mini funil de recrutamento” em cima da base da UNIGRAM.

### 6. Localização

Traz a dimensão geográfica:

- Quantas regiões, estados e cidades existem na base;
- Uma barra de “Distribuição de localizações”;
- Tipos de região (UF x cidade);
- Um mapa estilizado do Brasil com bolhas por cidade (quanto maior a bolha, mais posts).

É o tipo de visão que ajuda a entender onde a rede está mais forte e onde faria sentido investir em ação local.

### 7. Análise do RAI

O RAI é um “analista virtual” que monta um resumo mais opinativo em cima dos dados do filtro atual. A aba dele é quase uma central de comando:

- Sinal do dia (se a rede está “pegando fogo”, “deu uma esfriada” ou “tá de boa”);
+- Risco (se a atividade está concentrada em poucos autores, se o engajamento está baixo, etc.);
- Previsão de interações para os próximos 30 dias;
- Banner com pílulas rápidas (clima, risco, total de interações, interações/post, conversão de vagas);
- Heatmap de horários (dia da semana x faixas de hora);
- “Movers” – tags que mais cresceram ou caíram de uma semana para outra;
- Donut de qualidade de feed (com texto / sem texto / privado);
- Watchlist de alertas (o que acendeu amarelo/vermelho);
- TL;DR com três frases para quem só quer um resumo executivo;
- Tabela de cenários (base, com desafio, com vagas mais segmentadas, semana pesada de prova);
- Tabela de oportunidades por curso (onde faz mais sentido atuar agora).

O texto é propositalmente mais solto, como se o RAI estivesse “conversando” com quem lê, mas sempre fundamentado nos números do período.

### 8. Perfil & Gamificação

Por fim, tem o painel de perfil, voltado para gamificação por curso e por usuário:

- Nível e score do usuário logado (demo);
- Ranking global por curso;
- Distribuição de níveis;
- Badges (conquistas) de exemplo.

No mundo real, isso poderia ser plugado direto na experiência da própria rede, para incentivar participação contínua.

---

## Dados

Para permitir que tudo funcionasse sem servidor, os dados são gerados em memória, misturando:

- registros inspirados nos seus arquivos `DIM_PERSON`, `DIM_LOCALIZAÇÃO`, `FATO_POST` e `FATO_COMMENT`;
- um gerador determinístico de dados fictícios (posts, comentários, vagas, candidaturas, etc.).

Assim o painel se comporta como se estivesse em produção, mas sem depender de banco ou API.

---

## Sobre o objetivo do trabalho

A intenção aqui não é construir um produto final, mas **provar conceito**:

- mostrar como as informações da rede social acadêmica e de vagas podem ser organizadas em painéis diferentes, com recortes por período, curso e localização;
- ter um login simples (admin/admin) só para reproduzir minimamente a experiência de “entrar num sistema”;
- aproximar a leitura de algo que um coordenador, alguém de carreira ou um time de dados realmente usaria no dia a dia;
- testar uma camada de “leitura inteligente” (RAI) que fala a linguagem do usuário, em vez de só despejar gráficos.

Se em algum momento o projeto for para frente, boa parte dessa estrutura de visões já serviria como rascunho para um BI real sobre os dados da UNIGRAM, seja em Power BI, Looker, ou outro stack de analytics. 

